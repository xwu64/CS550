__author__ = 'wu'

stateDir = {'000': 'No problem',
            '001': 'Download Completely',
            '400': 'Invalid command',
            '401': 'Invalid file path in this client',
            '403': 'The command is valid, but the server is refusing to respond to it',
            '410': 'Invalid path in requested peer',
            '411': 'Invalid ip adress.',
            '500': 'Server encountered condition which prevent it from fullfilling the request',
            '901': '1000 register test',
            '902': '1000 download test'}


