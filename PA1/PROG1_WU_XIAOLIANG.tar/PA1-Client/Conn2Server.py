__author__ = 'wu'

from socket import *

def conn2server(msg, socketObj):

    return True
